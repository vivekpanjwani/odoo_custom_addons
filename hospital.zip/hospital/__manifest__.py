{
    "name":"Hospital",
    "version":"1.0",
    "depends":["base","mail"],
    "author":"Vivek Panjwani",
    "data":[
        "security/ir.model.access.csv",
        "views/department_view.xml",
        "views/appointment_view.xml",
        "views/medical_history_view.xml",
        "views/doctor_view.xml",
        "views/patient_views.xml",       
        ],
    "installable":True,
    "application":True,
    "auto_install":False,
    "summary":"Hospital Management System",
    "description":"Module to manage Hospital",
}
