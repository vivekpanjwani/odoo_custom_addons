from odoo import models, fields

class Hospital_doctor(models.Model):
    _name = 'hospital.doctor'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    _description = 'Doctor Record'

    name = fields.Char(string='Doctor Name', required=True)
    specialization=fields.Char(string="Specialization", required =True)

    doct_appointment=fields.Many2many('hospital.appointment', string="Appointment")
    doct_department=fields.One2many('hospital.department','department_id')

    patients=fields.One2many('hospital.patient','doctor_id')