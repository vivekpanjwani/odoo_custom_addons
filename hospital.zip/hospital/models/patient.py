from odoo import models,fields,api
from datetime import date

class Hospital_patient(models.Model):
    _name = 'hospital.patient'
    _description = 'Patient Info'

    name=fields.Char(string="Patient's Name", required=True)
    date_of_birth=fields.Date(string="Date of birth")
    age=fields.Float(string="Age", compute="_compute_age")
    gender=fields.Selection([('Male','Male'),('Female','Female'),('Others','Others')])
    
    street1=fields.Char(string="Street1")
    street2=fields.Char(string="Street2")
    city=fields.Char(string="City")
    state=fields.Many2one('res.country.state', string="State")
    country=fields.Many2one('res.country', string="Country")

    doctor_id=fields.Many2one('hospital.doctor', string="Assigned Doctor")
    appointment_ids=fields.Many2many('hospital.appointment', string="Appointments")

    medical_his=fields.One2many('hospital.medical.history', 'patient_id')
    

    @api.depends("date_of_birth")
    def _compute_age(self):
        today=date.today()
        for patient in self:
            if patient.date_of_birth:
                date_of_birth=fields.Date.from_string(patient.date_of_birth)
                age=today.year - date_of_birth.year - ((today.month,today.day)< (date_of_birth.month,date_of_birth.day))
                if patient.age<18:
                    raise ValueError("Age must be more than 18")
            else:
                patient.age=0

    @api.onchange("gender")
    def _onchange_gender(self):
        for record in self:
            if record.gender=="Others":
                return {
                    'warning': {'title': "Warning", 'message': "What is this?", 'type': 'notification'},
                }
    

                
