from odoo import models, fields

class Hospital_department(models.Model):
    _name = 'hospital.department'
    _description = 'Hospital Department'

    name=fields.Char(string="Name")
    department_id=fields.Many2one('hospital.doctor')
    
