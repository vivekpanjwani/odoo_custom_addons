from . import doctor
from . import appointment
from . import department
from . import medical_history
from . import patient
