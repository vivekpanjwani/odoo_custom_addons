from odoo import models, fields

class Hospital_medical_history(models.Model):
    _name = 'hospital.medical.history'
    _description = 'Medical History'

    description=fields.Char(string="Description")
    date=fields.Date(string="Date")
    patient_id=fields.Many2one("hospital.patient")
    
