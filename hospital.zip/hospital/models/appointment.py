from odoo import models, fields

class Hospital_appointment(models.Model):
    _name = 'hospital.appointment'
    _description = 'Appointment'

    date=fields.Date(string="Date")
    start_time = fields.Float(string="Start Time", required=True)
    end_time = fields.Float(string="End Time", required=True)
    doctor_id = fields.Many2one('hospital.doctor')
    patient_id = fields.Many2one('hospital.patient')
    